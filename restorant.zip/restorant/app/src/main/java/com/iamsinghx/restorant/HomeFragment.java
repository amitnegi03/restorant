package com.iamsinghx.restorant;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView mRecyclerView;
    View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);


        mRecyclerView = view.findViewById(R.id.restaurant_recyclerview_list);
        new FirebaseDatabaseHelper().readRestaurants(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<Restaurant> restaurants, List<String> keys) {

                new RecyclerView_Config().setConfig(mRecyclerView, getActivity(), restaurants, keys);
                view.findViewById(R.id.progressBar_restaurants).setVisibility(View.GONE);
            }

            @Override
            public void DataIsInserted() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });
        return view;
    }
}

