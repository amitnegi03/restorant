package com.iamsinghx.restorant;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerView_Config {
    private Context mContext;
    private RestaurantAdapter mRestaurantAdapter;

    public void setConfig(RecyclerView recyclerView, Context context, List<Restaurant> restaurants, List<String> keys) {
        mContext = context;
        mRestaurantAdapter = new RestaurantAdapter(restaurants, keys);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setAdapter(mRestaurantAdapter);
    }

    class RestaurantItemView extends RecyclerView.ViewHolder {
        private TextView mName;
        private TextView mAddress;
        private RatingBar mRating;

        private String key;

        public RestaurantItemView(ViewGroup parent) {
            super(LayoutInflater.from(mContext).
                    inflate(R.layout.restaurant_one, parent, false));

            mName = itemView.findViewById(R.id.rowName);
            mAddress = itemView.findViewById(R.id.rowAddress);
            mRating = itemView.findViewById(R.id.ratingBarList);
        }

        public void bind(Restaurant restaurant, String key) {
            mName.setText(restaurant.getName());
            mAddress.setText(restaurant.getAddress());
            mRating.setRating(Float.valueOf(restaurant.getRating()));
            this.key = key;
        }

    }

    class RestaurantAdapter extends RecyclerView.Adapter<RestaurantItemView> {
        private List<Restaurant> mRestaurantList;
        private List<String> mKeys;

        @NonNull
        @Override
        public RestaurantItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new RestaurantItemView(parent);
        }

        @Override
        public void onBindViewHolder(@NonNull final RestaurantItemView holder, final int position) {

            holder.bind(mRestaurantList.get(position), mKeys.get(position));
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    String s=mRestaurantList.get(position).getName();
                    //Toast.makeText(mContext, "click " + s, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(mContext, RestaurantActivity.class);
                    intent.putExtra("name", s);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    mContext.startActivity(intent);

                }
            });
        }

        @Override
        public int getItemCount() {
            return mRestaurantList.size();
        }

        public RestaurantAdapter(List<Restaurant> mRestaurantList, List<String> mKeys) {
            this.mRestaurantList = mRestaurantList;
            this.mKeys = mKeys;

        }
    }
}
