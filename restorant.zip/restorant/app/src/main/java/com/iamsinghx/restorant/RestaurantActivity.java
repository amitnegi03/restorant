package com.iamsinghx.restorant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.PrivateKey;
import java.util.Map;
import java.util.PriorityQueue;

public class RestaurantActivity extends AppCompatActivity {

    private CardView locationBtn;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private String name;
    private Double latitude;
    private Double longitude;
    private String hygiene;
    private String rating;
    private String address;
    private String description;
    private String mask;
    private String security;
    private String handWash;
    private String distance;


    private TextView resDescription;
    private RatingBar resRating;
    private TextView res_Hygiene;
    private TextView res_address, res_handWash, res_handWash2, res_sitting, res_Mask, res_security;

    private String TAG = "FirebaseData";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        resRating = findViewById(R.id.res_ratingBar);
        res_Hygiene = findViewById(R.id.res_hygieneView);
        res_address = findViewById(R.id.restaurant_address);
        resDescription = findViewById(R.id.res_description);

        res_handWash = findViewById(R.id.handWash);
        res_handWash2 = findViewById(R.id.handwash2);
        res_sitting = findViewById(R.id.sitting);
        res_Mask = findViewById(R.id.mask);
        res_security = findViewById(R.id.security2);


        getIncomingIntent();

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Restaurants");


        databaseReference.child(name).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Map<String, Object> data = (Map<String, Object>) dataSnapshot.getValue();

                //Toast.makeText(RestaurantActivity.this, " "+data.get("latitude"), Toast.LENGTH_SHORT).show();

                latitude = (Double) data.get("latitude");
                longitude = (Double) data.get("longitude");
                hygiene = (String) data.get("hygiene");
                rating = (String) data.get("rating");
                address = (String) data.get("address");
                description = (String) data.get("description");
                security=  (String) data.get("security");
                mask=  (String) data.get("mask");
                distance=  (String) data.get("distance");
                handWash=  (String) data.get("handWash");
                //Toast.makeText(RestaurantActivity.this, ""+security, Toast.LENGTH_SHORT).show();
                resRating.setRating(Float.parseFloat(rating));
                res_Hygiene.setText(hygiene + "%");
                res_address.setText(address);
                resDescription.setText(description);
                if(security.equals("true")){
                    res_security.setText("Yes");
                    res_security.setTextColor(Color.parseColor("#00FF00"));
                }
                else{
                    res_security.setText("No");
                    res_security.setTextColor(Color.parseColor("#DC143C"));
                }
                if(mask.equals("true")){
                    res_handWash.setText("Yes");
                    res_handWash.setTextColor(Color.parseColor("#00FF00"));
                }
                else{
                    res_handWash.setText("No");
                    res_handWash.setTextColor(Color.parseColor("#DC143C"));
                }
                if(handWash.equals("true")){
                    res_handWash2.setText("Yes");
                    res_handWash2.setTextColor(Color.parseColor("#00FF00"));
                }
                else{
                    res_handWash2.setText("No");
                    res_handWash2.setTextColor(Color.parseColor("#DC143C"));
                }
                if(distance.equals("true")){
                    res_sitting.setText("Yes");
                    res_sitting.setTextColor(Color.parseColor("#00FF00"));
                }
                else{
                    res_sitting.setText("No");
                    res_sitting.setTextColor(Color.parseColor("#DC143C"));
                }
                if(mask.equals("true")){
                    res_Mask.setText("Yes");
                    res_Mask.setTextColor(Color.parseColor("#00FF00"));
                }
                else{
                    res_Mask.setText("No");
                    res_Mask.setTextColor(Color.parseColor("#DC143C"));
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        locationBtn = findViewById(R.id.location);

        locationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenMapWithData(latitude, longitude, name, hygiene);
            }
        });
    }


    private void getIncomingIntent() {
        if (getIntent().hasExtra("name")) {
            name = getIntent().getStringExtra("name");
            setName(name);
        }
    }

    private void setName(String name) {
        TextView restaurantName = findViewById(R.id.res_name);
        restaurantName.setText(name);
    }

    private void OpenMapWithData(Double latitude, Double longitude, String name, String hygiene) {

        Intent intent = new Intent(RestaurantActivity.this, MapActivity.class);
        intent.putExtra("latitude", latitude);
        intent.putExtra("longitude", longitude);
        intent.putExtra("name", name);
        intent.putExtra("hygiene", hygiene);
        startActivity(intent);
    }
}