package com.iamsinghx.restorant;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ProfileFragment extends Fragment {
    private Button signOutButon;
    View view;
    private FirebaseAuth mAuth;
    private GoogleSignInClient mGoogleSignInClient;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {



        view =inflater.inflate(R.layout.fragment_profile,container,false);
        signOutButon = view.findViewById(R.id.sign_out_button);



        signOutButon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new LoginActivity().signOut();


                Intent intent =new Intent(getActivity(),LoginActivity.class);
                startActivity(intent);

            }
        });
        return view;
    }


}
