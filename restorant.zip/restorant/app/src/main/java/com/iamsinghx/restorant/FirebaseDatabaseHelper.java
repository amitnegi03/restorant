package com.iamsinghx.restorant;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

class FirebaseDatabaseHelper {
    private FirebaseDatabase mDatabase;
    private DatabaseReference mReferenceRestaurant;
    private List<Restaurant> restaurants= new ArrayList<>();

    public interface DataStatus{
        void DataIsLoaded(List<Restaurant> restaurants,List<String> keys);
        void DataIsInserted();
        void DataIsUpdated();
        void DataIsDeleted();
    }

    public FirebaseDatabaseHelper() {
        mDatabase = FirebaseDatabase.getInstance();
        mReferenceRestaurant=mDatabase.getReference("Restaurants");
    }

    public void readRestaurants(final DataStatus dataStatus){
        mReferenceRestaurant.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                restaurants.clear();
                List<String> keys =new ArrayList<>();
                for(DataSnapshot keyNode :dataSnapshot.getChildren()){
                    keys.add(keyNode.getKey());
                    Restaurant restaurant = keyNode.getValue(Restaurant.class);
                    restaurants.add(restaurant);
                }
                dataStatus.DataIsLoaded(restaurants,keys);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
