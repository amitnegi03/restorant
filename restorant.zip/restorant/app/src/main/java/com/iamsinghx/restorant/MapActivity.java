package com.iamsinghx.restorant;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {
    Double longitude;
    Double latitude;
    String name;
    String hygiene;
    GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_map);


        getIntentData();
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map_fragment);

        mapFragment.getMapAsync(this);
    }

    private void getIntentData() {

        

        latitude =getIntent().getDoubleExtra("latitude",0.0);

        longitude = getIntent().getDoubleExtra("longitude",0.0);
        name = getIntent().getStringExtra("name");
        hygiene = getIntent().getStringExtra("hygiene");
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        LatLng latLng = new LatLng(latitude, longitude);
        map.addMarker(new MarkerOptions().position(latLng).title(""+name+" "+hygiene+"% Hygiene"));
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,15));
    }
}