package com.iamsinghx.restorant;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import java.util.List;


public class RestaurantListActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_list);



        mRecyclerView = findViewById(R.id.restaurant_recyclerview_list);
        new FirebaseDatabaseHelper().readRestaurants(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoaded(List<Restaurant> restaurants, List<String> keys) {

                new RecyclerView_Config().setConfig(mRecyclerView,RestaurantListActivity.this,restaurants,keys);
                findViewById(R.id.progressBar_restaurants).setVisibility(View.GONE);
            }

            @Override
            public void DataIsInserted() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });
    }

}
