package com.iamsinghx.restorant;

interface OnLoadMoreListener {
    void onLoadMore();
}
